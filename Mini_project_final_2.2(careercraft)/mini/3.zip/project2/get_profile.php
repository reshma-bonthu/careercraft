<?php
session_start();
require_once 'db_connect.php'; // Assuming this file connects to your database

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php'); // Redirect to login page if not logged in
    exit;
}

// Fetch user details from database
$username = $_SESSION['username'];
$query = "SELECT email, bio FROM reg WHERE username = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $username);
$stmt->execute();
$stmt->bind_result($email, $bio);
$stmt->fetch();
$stmt->close();

// Return JSON response
$profileData = [
    'username' => $username,
    'email' => $email,
    'bio' => $bio,
];

echo json_encode($profileData);
?>