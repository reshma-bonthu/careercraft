<?php
// Assuming you have a database connection established
include 'db_connect.php';

// Start session (assuming sessions are used for login)
session_start();

// Check if user is logged in, adjust this according to your login mechanism
if (!isset($_SESSION['username'])) {
    die('User not logged in'); // Handle appropriately
}

// Update bio in database for logged-in user
$username = $_SESSION['username'];
$bio = $_POST['bio'];

$stmt = $pdo->prepare('UPDATE reg SET bio = :bio WHERE username = :username');
$result = $stmt->execute(['bio' => $bio, 'username' => $username]);

if ($result) {
    echo 'Profile updated successfully';
} else {
    echo 'Failed to update profile'; // Handle error
}
?>